<?php
/**
 * @package Cấu hình Thẻ siêu rẻ
 *
 * @author Vinh Developer | Ske Software | Phạm Vinh ID
 *
 * @see Lưu ý: Token captcha phải được lấy chính xác thì mới có thể đăng nhập được vào tài khoản ! Cách lấy xin liên hệ Zalo: 0931562864 - Vinh Developer hoặc xem trong phần Hướng dẫn
 *
 * @method Nếu lỗi đăng nhập: Mã xác nhận không chính xác thì token captcha bị sai và phải lấy lại
 */
namespace SkeSoft;
class Config {
	// Ghi lại nhật ký hoạt động (true nếu có hoặc false nếu không)
	public const LOGGING = true;

	// Cài đặt tài khoản (bắt buộc)
	public const TSR_USERNAME = 'vinh2007'; // Username tài khoản thẻ siêu rẻ
	public const TSR_PASSWORD = 'v2i0n0h7'; // Mật khẩu thẻ siêu rẻ

	// Tự động xóa file lưu cookie (true nếu bật hoặc false nếu tắt, khuyến khích nên để false)
	public const AUTO_DELETE_COOKIE = false; // Tính năng này sẽ lưu cookie tài khoản trong 1 thời gian dài để đăng nhập không cần captcha token, nếu bạn đổi tài khoản tsr bắt buộc phải xóa cookie. Cách xóa cookie xem trong hướng dẫn.

	// Token captcha ở thẻ siêu rẻ (bắt buộc, cách lấy token ở hướng dẫn)
	public const G_CAPTCHA_CODE = '03AGdBq253NSHuG4XiA35S3BjoMpvD6MQwTPg7hk1hwPZD2wjCTiDQ8wW7VSq7_qF2p7o-cY2ZfscRnE5lx0uXcpwoeIXgeitrcv5mYVxPlPjL6Ba6JOok2N7oHIsy1VGAScLvm3UzdQwpN9hNI_K-NTAaH6k84NLotdTP8j0jtd0lhca-ufEt4_XILGa5OPv82ZO67hLtO5MjzXbhd5sbBrd2yzBpoioONcCaznt3b_TZrDpCqEsszL84Kb4_Ckpeu05kHu1lXWAXfe0pnHPruwrVGbYtP8Ilkr9610J55I_LiYjxMtqPx5W2RrKsFPf1Qlh8OyZL7HNA8wXGPgR78U479vlAvd5ghAaY_YzPrfemIxb2IynDZpU0Pj6Zjmdf82wp935jK2EOwFVQP1n-khtsIUO_a92IWViXld8ijxYhKLUrHkYYEoh94qQ5gbcooeA-QFpVktHCOTNffA-4-Iur0hYhgtLHx0JnHY869q8gDoI29Irc-JKh85TIzUjAoZCyMC21n8EG';
}